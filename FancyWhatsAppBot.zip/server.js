const express = require('express');
const { WAConnection } = require('@adiwajshing/baileys');
const fs = require('fs');
const qrcode = require('qrcode');
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.send(`
        <h1>ربط بوت الواتساب</h1>
        <form action="/connect" method="POST">
            <label>رقم الواتساب (مثال: 20123456789):</label>
            <input type="text" name="number" required />
            <button type="submit">ربط الرقم</button>
        </form>
    `);
});

app.post('/connect', async (req, res) => {
    const { number } = req.body;
    if (!number) return res.send('حط رقم الواتساب!');

    const conn = new WAConnection();
    conn.on('open', () => {
        const authInfo = conn.base64EncodedAuthInfo();
        fs.writeFileSync('./creds.json', JSON.stringify(authInfo, null, '\t'));
        res.send('تم الربط! ملف الجلسة (creds.json) جاهز. انسخه من المشروع.');
    });

    try {
        await conn.connect();
        conn.user.jid = `${number}@s.whatsapp.net`;
    } catch (err) {
        res.send('في مشكلة في الربط، جرب رقم تاني!');
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`السيرفر شغال على بورت ${PORT}`));