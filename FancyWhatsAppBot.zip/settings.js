module.exports = {
    botName: "FancyWhatsAppBot",
    ownerNumber: "201557409072@s.whatsapp.net", // حط رقمك هنا مع @s.whatsapp.net
    prefix: "."
};