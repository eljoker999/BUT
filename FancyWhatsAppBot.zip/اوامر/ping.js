module.exports = {
    name: 'ping',
    description: 'اختبار سرعة البوت',
    async execute(conn, message, args) {
        const sender = message.key.remoteJid;
        await conn.sendMessage(sender, 'بونج! 🏓 البوت شغال زي الفل', MessageType.text);
    }
};