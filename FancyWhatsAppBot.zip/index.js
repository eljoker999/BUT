const { WAConnection, MessageType } = require('@adiwajshing/baileys');
const fs = require('fs');
const path = require('path');
const commandsPath = path.join(__dirname, 'اوامر');
const settings = require('./settings');

// تحميل الأوامر
const commands = new Map();
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const command = require(path.join(commandsPath, file));
    commands.set(command.name, command);
}

async function startBot() {
    const conn = new WAConnection();
    
    // تحميل ملف الجلسة
    if (fs.existsSync('./creds.json')) {
        conn.loadAuthInfo('./creds.json');
    }

    // الاتصال بالواتساب
    conn.on('open', () => {
        console.log('تم الاتصال بالواتساب!');
        const authInfo = conn.base64EncodedAuthInfo();
        fs.writeFileSync('./creds.json', JSON.stringify(authInfo, null, '\t'));
    });

    // استقبال الرسائل
    conn.on('chat-update', async chat => {
        if (!chat.hasNewMessage) return;
        const m = chat.messages.all()[0];
        if (!m.message) return;
        if (m.key.fromMe) return;

        const sender = m.key.remoteJid;
        const message = m.message.conversation || m.message.extendedTextMessage?.text || '';

        // التحقق من الأوامر
        if (message.startsWith('.')) {
            const args = message.slice(1).trim().split(/ +/);
            const commandName = args.shift().toLowerCase();
            const command = commands.get(commandName);

            if (command) {
                try {
                    await command.execute(conn, m, args);
                } catch (error) {
                    console.error(error);
                    conn.sendMessage(sender, 'في مشكلة في الأمر، جرب تاني!', MessageType.text);
                }
            }
        }

        // قائمة الأوامر التفاعلية
        if (message === 'القائمة' || message === 'menu') {
            const buttons = [
                { buttonId: 'cmd1', buttonText: { displayText: 'أمر 1' }, type: 1 },
                { buttonId: 'cmd2', buttonText: { displayText: 'أمر 2' }, type: 1 },
            ];
            const buttonMessage = {
                contentText: `مرحباً! إليك قائمة الأوامر:\n\nاختر أمر من الأزرار 📋`,
                footerText: settings.botName,
                buttons: buttons,
                headerType: 1
            };
            conn.sendMessage(sender, buttonMessage, MessageType.buttonsMessage);
        }
    });

    // الاتصال
    await conn.connect();
}

startBot().catch(err => console.error('خطأ في تشغيل البوت:', err));